# I3-Pro-B
Firmware Marlin 1.1.9 for Geeetech I3 Pro B.  
With T8x2 rods.  
A4988 drivers.  
Mesh leveling 4x4 points.  
Upload directly with lastest Arduino Ide.  
